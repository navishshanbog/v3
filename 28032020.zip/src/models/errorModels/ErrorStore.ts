
import ErrorModel from "./ErrorModel";

const ErrorStore = new ErrorModel();

export { ErrorStore };
