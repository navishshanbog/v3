
export default interface IErrorModel {
    hasErrors: boolean;
    message: string;
    showError: boolean;
    resetErrors(): void;
    setErrors(_hasErrors?: boolean): void;
    setErrorMsg(_message?: string, _showError?: boolean);
}

//export default IErrorModel as IErrorModel, IErrorObject;
//export { IErrorModel as default, IErrorObject };
