import IErrorModel from "./IErrorModel";
import {observable} from "mobx";

class ErrorModel implements IErrorModel {

    @observable hasErrors = false;
    @observable showError = false;
    @observable message = "";

    constructor() {
        this.hasErrors = false;
        this.showError = false;
        this.message = "";
    }

    setErrors(_hasErrors?: boolean): void {
        this.hasErrors = _hasErrors;
    }

    setErrorMsg(_message?: string, _showError?: boolean) {
        this.showError = _showError;
        this.message = _message;
    }

    resetErrors(): void {
        this.showError = false;
        this.hasErrors = false;
        this.message = "";
    }
}

export default ErrorModel;
