

import INavigationModel from "./INavigationModel";
import {observable} from "mobx";


class NavigationModel implements INavigationModel {
    @observable hoverIndex = -1;
    @observable navOpen = false;

    setHoverIndex(_hoverIndex?: number): void {
        this.hoverIndex = _hoverIndex;
    }

    setNavOpen(_navOpen: boolean): void {
        this.navOpen = _navOpen;
    }

}
export { NavigationModel };
