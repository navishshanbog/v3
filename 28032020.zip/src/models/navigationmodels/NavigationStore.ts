
import {NavigationModel} from "./NavigationModel";

const NavigationStore = new NavigationModel();

export { NavigationStore };
