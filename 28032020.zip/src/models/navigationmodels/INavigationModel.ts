
interface INavigationModel {
    hoverIndex?: number;
    setHoverIndex(_hoverIndex?: number): void;
    navOpen?: boolean;
    setNavOpen(_navOpen?: boolean): void;
}


export default INavigationModel
