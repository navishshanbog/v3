import IErrorModel from "../errorModels/IErrorModel";

interface ILoginModel {
    phoneNumber?: string;
    passCode?: string;
    confirmPassCode?: string;
    authCode?: string;
    errorModel: IErrorModel;
    userEntry?: boolean;
    displayData?: string;

    lgnAuthenUser(): void;
    showLogin?: boolean;
    storeUserEntry(storeNumber?: string): void;
    toggleOpenClose(showLogin?: boolean): void;
    undoUserInput(): void;
    // For temp state of login
    activeStep?: number;
    setStepForward(): void;
    setStepBackward(): void;
    setActiveStep(_activeStep: number, toValidate: boolean): void;

}






export default ILoginModel
