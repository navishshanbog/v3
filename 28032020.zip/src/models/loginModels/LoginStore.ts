
import {LoginModel} from "./LoginModel";

const LoginStore = new LoginModel();

export { LoginStore };
