

import ILoginModel from "./ILoginModel";
import { MAX_PASSCODE_LENGTH, MAX_PHONENUMBER_LENGTH, PHONE_STARTSWITH} from "../../assets/V3Constants";
import {computed, observable} from "mobx";
import IErrorModel from "../errorModels/IErrorModel";
import ErrorModel from "../errorModels/ErrorModel";
import {isBlank} from "../../assets/util/String";


class LoginModel implements ILoginModel {

    @observable phoneNumber = "";
    @observable passCode = "";
    @observable confirmPassCode = "";
    @observable authCode  = "";
    @observable showLogin = false;
    @observable activeStep = 0;
    @observable errorModel: IErrorModel = new ErrorModel();
    @observable userEntry = false;

    constructor() {
        this.errorModel.setErrors(false);
        this.errorModel.setErrorMsg("", false);
    }

    lgnAuthenUser(): void {
        console.log("-- authenticate with the following ", this.phoneNumber);
        console.log("-- authenticate with the following ", this.passCode);
        console.log("-- authenticate with the following ", this.confirmPassCode);
        console.log("-- authenticate with the following ", this.authCode);
    }

    toggleOpenClose(showLogin?: boolean) {
        this.showLogin = showLogin;
    }

    setStepForward(): void {
        this.activeStep = this.activeStep + 1;
        this.userEntry = !this.waitingUserInput();
        console.log("-- user enty", this.userEntry)
    }

    setStepBackward(): void {
        this.activeStep = this.activeStep -1;
        this.userEntry = !this.waitingUserInput();
        console.log("-- user enty", this.userEntry)
    }

    waitingUserInput = () => {
        switch (this.activeStep) {
            case 0:
                 return isBlank(this.phoneNumber);
            case 1:
                return isBlank(this.passCode);
            case 2:
                return isBlank(this.confirmPassCode);
            case 3:
                return isBlank(this.authCode);
        }
    }

    setActiveStep(_activeStep?: number, toValidate?: boolean): void {
        console.log("-- th enext step ");
        if(toValidate) {
            this.validate();
        } else {
            this.errorModel.hasErrors=false;
        }
        if(!this.errorModel.hasErrors) {
            this.activeStep = _activeStep;
            this.userEntry = false;
        }
    }

    storeUserEntry(number?: string) {
        switch (this.activeStep) {
            case 0:
                this.phoneNumber = this.phoneNumber.concat(number);
                this.userEntry = this.phoneNumber.length >=1;
                this.validate();
                console.log("--the length ",  this.phoneNumber.length);
                break;
            case 1:
                if(this.passCode.length<4) {
                    this.passCode = this.passCode.concat(number);
                    this.userEntry = this.passCode.length >= 1;
                    this.validate();
                    console.log("--the length ", this.passCode.length);
                }
                break;
            case 2:
                if(this.confirmPassCode.length<4) {
                    this.confirmPassCode = this.confirmPassCode.concat(number);
                    this.userEntry = this.confirmPassCode.length >= 1;
                    this.validate();
                    console.log("--the length ", this.confirmPassCode.length);
                }
                break;
            case 3:
                this.authCode = this.authCode.concat(number);
                this.userEntry = this.authCode.length >=1;
                this.validate();
                console.log("--the length ",  this.authCode.length);
                break;
        }

    }

    undoUserInput() {
        switch (this.activeStep) {
            case 0:
                if(this.phoneNumber.length>1) {
                    this.phoneNumber = this.phoneNumber.slice(0, -1);
                    this.errorModel.showError = false;
                } else {
                    this.phoneNumber = "";
                    this.userEntry = false;
                }
                break;
            case 1:
                if(this.passCode.length>1) {
                    this.passCode = this.passCode.slice(0, -1);
                } else {
                    this.passCode = "";
                    this.userEntry = false;
                }
                break;
            case 2:
                if(this.confirmPassCode.length>1) {
                    this.confirmPassCode = this.confirmPassCode.slice(0, -1);
                } else {
                    this.confirmPassCode = "";
                    this.userEntry = false;
                }
                break;
        }
    }


    validate () {
        this.errorModel.resetErrors();
        switch (this.activeStep) {
            case 0:
                if(this.phoneNumber.length !== MAX_PHONENUMBER_LENGTH || !this.phoneNumber.startsWith(PHONE_STARTSWITH)) {
                    this.errorModel.message = "Invalid phone number";
                    this.errorModel.showError = this.phoneNumber.length === MAX_PHONENUMBER_LENGTH;
                    this.errorModel.hasErrors = true
                }
                break;
            case 1:
                if(this.passCode.length !== MAX_PASSCODE_LENGTH) {
                    this.errorModel.message = "Invalid Passcode length";
                    this.errorModel.showError = true;
                    this.errorModel.hasErrors = true
                }
                break;
            case 2:
                if(this.confirmPassCode.length !== MAX_PASSCODE_LENGTH) {
                    this.errorModel.message = "Invalid Passcode length";
                    this.errorModel.showError = true;
                    this.errorModel.hasErrors = true
                }
                break;
            case 3:
                return true;
        }
        if(this.activeStep === 2 && !this.errorModel.showError) {
            if(!(this.passCode === this.confirmPassCode)) {
                this.errorModel.message = "Passcode do not match. Please try again";
                this.errorModel.showError = true;
                this.errorModel.hasErrors = true;
            }
        }
    }


    @computed
    get displayData() {
        let displayData = "";
        switch (this.activeStep) {
            case 0:
                displayData = this.phoneNumber; break;
            case 1:
                displayData =  this.passCode.replace(/./gi, '*');
                console.log("-- display data ", displayData);
                break;
            case 2:
                displayData =  this.confirmPassCode.replace(/./gi, '*'); break;
            case 3:
                displayData =  this.authCode; break;
            default:
                displayData =  'Unknown step';
        }
        return displayData;
    }
}

export { LoginModel };

