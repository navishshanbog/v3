import React from 'react';
import {
    Link
} from "react-router-dom";
import { observer } from "mobx-react";
import INavigationModel from "../../models/navigationmodels/INavigationModel";


interface INavigationProps {
    navigationLinks?: any;
    background?: string;
    hoverBackground?: string;
    linkColor?: string;
    logo?: any;
    navigationModel?: INavigationModel;
}

@observer
class Navigation extends React.Component<INavigationProps, any> {

    setHoverIndex(index: number ) {
        this.props.navigationModel.setHoverIndex(index);
    }

    render() {
        return (
            <nav
                className="responsive-toolbar"
                style={{background: this.props.background || "#333"}}>
                <ul
                    className={this.props.navigationModel.navOpen ? 'active': ''}
                    style={{background: this.props.background || "#333"}}>
                    <figure onClick={() => this.props.navigationModel.setNavOpen(!this.props.navigationModel.navOpen)}>
                        <img src={this.props.logo} height="40px" width="40px" alt={"logo-nav-toggler"} />
                    </figure>
                    {this.props.navigationLinks.map((navLink, index) => {
                        return (<li onMouseEnter={() => this.setHoverIndex(index)} key={index}
                                    onMouseLeave={() => this.setHoverIndex(-1)}
                                    className={navLink.specialStyle ? navLink.specialStyle : ""}
                                    style={{background: this.props.navigationModel.hoverIndex === index ?
                                            (this.props.hoverBackground || "#999"): ""}}>
                            <Link onClick={() => this.props.navigationModel.setNavOpen(false)}
                                to={navLink.path}
                                style={{color: this.props.linkColor}}>
                                {navLink.text}
                                <i className={navLink.icon} />
                            </Link>
                        </li>)

                    })}
                </ul>

            </nav>
        )
    }
}

export { Navigation }

