import React from 'react';

interface IRegistration {

}

class Registration extends React.Component {
    render() {
        return (
            <div style={{paddingLeft: "60px"}}>
                <h1>ABout Page </h1>
            </div>
        )
    }
}

export { Registration }
