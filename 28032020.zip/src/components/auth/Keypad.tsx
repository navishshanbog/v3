import React from 'react';
import "./Keypad.scss";

import { observer } from "mobx-react";


interface Ikeypad {
    onKeyClick(ev: any): void;
    activeStep?: number;
    stepsLength?: number;
    handleNext(ev: any): void;
    handleBack(ev: any): void;
    disableNext?: boolean;
}

@observer
class Keypad extends React.Component<Ikeypad, any> {
    render() {
        console.log("-- the disabled button ", this.props.disableNext);
        return (
            <div className="button">

                <button name="1" value={1} onClick={e => this.props.onKeyClick(e.target)}>1</button>
                <button name="2" value={2} onClick={e => this.props.onKeyClick(e.target)}>2</button>
                <button name="3" value={3} onClick={e => this.props.onKeyClick(e.target)}>3</button>
                <br/>


                <button name="4" value={4} onClick={e => this.props.onKeyClick(e.target)}>4</button>
                <button name="5" value={5} onClick={e => this.props.onKeyClick(e.target)}>5</button>
                <button name="6" value={6} onClick={e => this.props.onKeyClick(e.target)}>6</button>
                <br/>

                <button name="7" value={7} onClick={e => this.props.onKeyClick(e.target)}>7</button>
                <button name="8" value={8} onClick={e => this.props.onKeyClick(e.target)}>8</button>
                <button name="9" value={9} onClick={e => this.props.onKeyClick(e.target)}>9</button>
                <br/>


                <button name="back" disabled={this.props.activeStep === 0}
                        onClick={e=> this.props.handleBack(e)} >
                    <i className="fas fa-arrow-circle-left" />
                </button>
                <button name="0" value={0} onClick={e => this.props.onKeyClick(e.target)}>0</button>
                <button name="next" disabled = {this.props.disableNext}
                        onClick={e => this.props.handleNext(e.target)}>
                    <i className="fas fa-arrow-circle-right" />
                </button>
                <br/>
            </div>
        )
    }
}

/*
onClick={e => this.props.onKeyClick(e.target)}
 */

export { Keypad }
