import React from 'react';
import ILoginModel from "../../models/loginModels/ILoginModel";
import { observer } from "mobx-react";
import {Keypad} from "./Keypad";
import "./Login.scss";
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import Stepper from "@material-ui/core/Stepper";
import Step from "@material-ui/core/Step";
import StepLabel from "@material-ui/core/StepLabel";
import {useColorlibStepIconStyles, ColorlibConnector, getStepContent, getSteps } from "../../assets/references/login.styles";
import clsx from "clsx";
import { StepIconProps } from "@material-ui/core/StepIcon";
import classNames from "classnames";




export function ColorlibStepIcon(props: StepIconProps) {
    const classes = useColorlibStepIconStyles();
    const { active, completed } = props;

    const icons: { [index: string]: React.ReactElement } = {
        1: <LoginIcons iconName="fas fa-mobile"/>,
        2: <LoginIcons iconName="fas fa-key"/>,
        3: <LoginIcons iconName="fas fa-lock"/>,
        4:< LoginIcons iconName="fas fa-unlock"/>,
    };

    return (
        <div
            className={clsx(classes.root, {
                [classes.active]: active,
                [classes.completed]: completed,
            })}
        >
            {icons[String(props.icon)]}
        </div>
    );
}


interface ILogin {
    userLoginModel?: ILoginModel;
}


interface ILoginIcons {
    iconName?: string;
}

export class LoginIcons extends React.Component<ILoginIcons, any> {
    render() {
        return <i className={this.props.iconName}/>
    }
}


@observer
class Login extends React.Component<ILogin, any> {
    steps = getSteps();

    handleNext = () => {
        this.props.userLoginModel.setStepForward();
        //this.props.userLoginModel.setActiveStep(this.props.userLoginModel.activeStep + 1, true); // true to validate the input
    };

    handleBack = () => {
        this.props.userLoginModel.setStepBackward();
        //this.props.userLoginModel.setActiveStep(this.props.userLoginModel.activeStep - 1, false); // not to validate the input
    };

    handleLogin = () => {
        this.props.userLoginModel.setActiveStep(0, false);
    };

    undoUserInput = () => {
        this.props.userLoginModel.undoUserInput();
    }

    storeUserEntry = (storeNumber: any) => {
        this.props.userLoginModel.storeUserEntry(storeNumber.value);
    };

    display = () => {
        console.log("-- do something");
    };

    render() {

        let content;
        if(this.props.userLoginModel.showLogin) {
            content = <div className="login-body">
                <p className={classNames("clear", "center")}>
                    <i className={classNames("signIn-icon", "fas fa-3x fa-lock")} />
                </p>
                    <Typography style={{marginTop: '8px', marginBottom: '8px'}}
                                className = {this.props.userLoginModel.errorModel.hasErrors &&
                                this.props.userLoginModel.userEntry? "error": ""}>
                        {this.props.userLoginModel.userEntry ? this.props.userLoginModel.displayData: "Enter your mobile Number"}
                        {this.props.userLoginModel.userEntry ?
                            <i className="fas fa-backspace login-backspace" onClick={this.undoUserInput}> </i>: null}
                    </Typography>
                <hr />
                <Typography style={{marginTop: '8px', marginBottom: '8px'}}
                            className = {this.props.userLoginModel.errorModel.hasErrors ? "error": ""}>
                    {this.props.userLoginModel.errorModel.showError ? this.props.userLoginModel.errorModel.message: ""}
                </Typography>
                    <div className="calculator-body">
                        <Keypad onKeyClick={this.storeUserEntry}
                                activeStep={this.props.userLoginModel.activeStep}
                                stepsLength={this.steps.length-1}
                                handleNext={this.handleNext}
                                disableNext={!this.props.userLoginModel.userEntry
                                || this.props.userLoginModel.errorModel.hasErrors}
                                handleBack={this.handleBack}/>
                    </div>
                </div>
        } else {
            content = <div className="login-body">
                <Stepper alternativeLabel activeStep={this.props.userLoginModel.activeStep}
                         connector={<ColorlibConnector />}
                         className="login-stepper">
                    {this.steps.map(label => (
                        <Step key={label}>
                            <StepLabel StepIconComponent={ColorlibStepIcon}>{label}</StepLabel>
                        </Step>
                    ))}
                </Stepper>
                <hr />
                <div>
                    {this.props.userLoginModel.activeStep === this.steps.length ? (
                        <div>
                            <Typography  style={{marginTop: '8px', marginBottom: '8px'}}>
                                Congratulation! You are now a member of V3
                            </Typography>
                            <Button onClick={this.handleLogin} style={{marginRight: '8px'}}>
                                Login
                            </Button>
                        </div>
                    ) : (
                        <div>
                            <Typography style={{marginTop: '8px', marginBottom: '8px'}}
                                        className = {this.props.userLoginModel.errorModel.hasErrors && this.props.userLoginModel.userEntry? "error": ""}>
                                {
                                    this.props.userLoginModel.userEntry ? this.props.userLoginModel.displayData:
                                        getStepContent(this.props.userLoginModel.activeStep
                                        )}
                                {this.props.userLoginModel.userEntry ? <i className="fas fa-backspace login-backspace" onClick={this.undoUserInput}> </i>: null}
                            </Typography>
                            <div className="calculator-body">
                                <Keypad onKeyClick={this.storeUserEntry}
                                        activeStep={this.props.userLoginModel.activeStep}
                                        stepsLength={this.steps.length-1}
                                        handleNext={this.handleNext}
                                        disableNext={!this.props.userLoginModel.userEntry
                                        || this.props.userLoginModel.errorModel.hasErrors}
                                    //|| this.props.userLoginModel.activeStep === this.steps.length-1}
                                        handleBack={this.handleBack}/>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        }

        return ( content
        )
    }
}

export { Login }

