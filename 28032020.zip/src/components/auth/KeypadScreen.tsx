import React, {Component} from 'react';
import "./KeypadScreen.scss";

interface IKeypadScreen {
    display?: any;
}
class KeypadScreen extends Component <IKeypadScreen, any> {


    render() {
        return (
            <div className="result">
                <p>{this.props.display}</p>
            </div>
        )
            ;
    }
}


export default KeypadScreen;
