import React from 'react';

class Portfolio extends React.Component {
    render() {
        return (
            <div>
                <h1> Portfolio  Page </h1>
            </div>
        )
    }
}

export { Portfolio }
