import React from 'react';

class Blog extends React.Component {
    render() {
        return (
            <div style={{paddingLeft: "60px"}}>
                <h1> Blog  Page </h1>
            </div>
        )
    }
}

export { Blog }
