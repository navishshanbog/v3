import React from 'react';

class About extends React.Component {
    render() {
        return (
            <div style={{paddingLeft: "60px"}}>
                <h1>ABout Page </h1>
            </div>
        )
    }
}

export { About }
