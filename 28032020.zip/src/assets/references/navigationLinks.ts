const navigationLinks = [
    {
        text: "Home",
        path: "/",
        icon: "fas fa-home"
    },
    // {
    //     text: "Contact",
    //     path: "/contact",
    //     icon: 'ion-home'
    // },
    {
        text: "Agencies",
        path: "/agencies",
        icon: 'fab fa-adn'
    },
    {
        text: "P E",  //nrop strocse
        path: "/about",
        icon: 'fab fa-product-hunt'
    },
    {
        text: "S E", //ehs elam
        path: "/contact",
        icon: "fab fa-studiovinari" //'fab fa-stripe-s'
    },
    {
        text: "Top 50",
        path: "/portfolio",
        icon: 'fab fa-500px'
    },
    {
        text: "Videos",
        path: "/blog",
        icon: 'fas fa-video'
    },
    {
        text: "Login",
        path: "/login",
        icon: 'fas fa-sign-in-alt',  //<i class="fas fa-lock"></i>
        specialStyle: "align-right"
    },
    {
        text: "Advertise For Free",
        path: "/advertise",
        icon: 'fas fa-ad'
    }
];


export { navigationLinks }
