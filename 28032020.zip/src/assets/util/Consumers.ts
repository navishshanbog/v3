import IConsumerFunc from "./IConsumerFunc";

// for now
const useless : IConsumerFunc = () => {};

export default useless;
