
export const MAX_PASSCODE_LENGTH = 4;
export const MAX_PHONENUMBER_LENGTH = 10;
export const PHONE_STARTSWITH = '04';

