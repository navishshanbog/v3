import React from 'react';
import './App.css';
import {
    BrowserRouter as Router,
    Switch,
    Route
} from "react-router-dom";
import { navigationLinks } from "./assets/references/navigationLinks";
import { About } from "./components/pages/About";
import { Blog } from "./components/pages/Blog";
import { Contact } from "./components/pages/Contact";
import { Portfolio } from "./components/pages/Portfolio";
import { Home } from "./components/pages/Home";
import {Navigation} from "./components/navigation/Navigation";
import  { Login }  from "./components/auth/Login";
import logo from "./logo.svg";
import INavigationModel from "./models/navigationmodels/INavigationModel";
import {NavigationModel} from "./models/navigationmodels/NavigationModel";
import ILoginModel from "./models/loginModels/ILoginModel";
import { LoginModel } from "./models/loginModels/LoginModel";


class App extends React.Component<any, any> {
    private navModel : INavigationModel;
    private loginModel: ILoginModel;

    get navigationModel() : INavigationModel {
        if(!this.navModel) {
            this.navModel = new NavigationModel();
        }
        return this.navModel;
    }

    get userLoginModel() : ILoginModel {
        if(!this.loginModel) {
            this.loginModel = new LoginModel();
        }
        this.loginModel.toggleOpenClose(true);
        return this.loginModel;
    }

    render() {
    return (
        <div>
            <Router>
                <Navigation
                    navigationLinks={navigationLinks}
                    logo={logo}
                    hoverBackground={"#ddd"}
                    linkColor={"#777"}
                    navigationModel={this.navigationModel}
                />

              <Switch>
                  <Route path="/about"><About /></Route>
                  <Route path="/contact"><Contact /></Route>
                  <Route path="/portfolio"><Portfolio /></Route>
                  <Route path="/blog"><Blog /></Route>
                  <Route path="/login"><Login userLoginModel={this.userLoginModel} /></Route>
                  <Route path="/"><Home /></Route>
              </Switch>
          </Router>
        </div>
    )
  }
}

//

export default App;
